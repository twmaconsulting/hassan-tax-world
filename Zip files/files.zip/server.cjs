const express  = require("express");
const multer   = require("multer");
const cors     = require("cors");
const fs       = require("fs");
const path     = require("path");
const https    = require("https");
const { exec } = require("child_process");

const app       = express();
const PORT      = 3001;
const FILES_DIR = path.join(__dirname, "tax-files");

// ── YOUR ANTHROPIC API KEY ──────────────────────────────────────────────────
// Get your free key at: https://console.anthropic.com
// Paste it between the quotes below:
const ANTHROPIC_API_KEY = "YOUR_API_KEY_HERE";
// ────────────────────────────────────────────────────────────────────────────

if (!fs.existsSync(FILES_DIR)) fs.mkdirSync(FILES_DIR, { recursive: true });

app.use(cors());
app.use(express.json({ limit: "50mb" }));

// ── AI proxy — forwards requests to Anthropic ────────────────────────────────
app.post("/api/ai", (req, res) => {
  if (!ANTHROPIC_API_KEY || ANTHROPIC_API_KEY === "YOUR_API_KEY_HERE") {
    return res.status(400).json({ error: "API key not set. Open server.cjs and add your Anthropic API key." });
  }

  const body = JSON.stringify({
    model: "claude-sonnet-4-20250514",
    max_tokens: 2000,
    ...req.body
  });

  const options = {
    hostname: "api.anthropic.com",
    path: "/v1/messages",
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
      "Content-Length": Buffer.byteLength(body),
    },
  };

  const apiReq = https.request(options, (apiRes) => {
    let data = "";
    apiRes.on("data", chunk => data += chunk);
    apiRes.on("end", () => {
      try { res.json(JSON.parse(data)); }
      catch { res.status(500).json({ error: "Invalid response from Anthropic" }); }
    });
  });

  apiReq.on("error", e => res.status(500).json({ error: e.message }));
  apiReq.write(body);
  apiReq.end();
});

// ── File upload setup ────────────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, FILES_DIR),
  filename: (req, file, cb) => {
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
    const dest = path.join(FILES_DIR, safe);
    if (fs.existsSync(dest)) {
      const ext = path.extname(safe), base = path.basename(safe, ext);
      cb(null, `${base}_${Date.now()}${ext}`);
    } else cb(null, safe);
  },
});
const upload = multer({ storage, limits: { fileSize: 500 * 1024 * 1024 } });

// ── File routes ───────────────────────────────────────────────────────────────
app.get("/api/files", (req, res) => {
  try {
    const files = fs.readdirSync(FILES_DIR).map(name => {
      const stat = fs.statSync(path.join(FILES_DIR, name));
      return { name, size: stat.size, modified: stat.mtime };
    });
    res.json(files);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/upload", upload.array("files", 50), (req, res) => {
  res.json({ ok: true, files: req.files.map(f => ({ name: f.filename, original: f.originalname, size: f.size })) });
});

app.get("/api/file/:name", (req, res) => {
  const fp = path.join(FILES_DIR, req.params.name);
  if (!fs.existsSync(fp)) return res.status(404).json({ error: "Not found" });
  res.sendFile(fp);
});

app.get("/api/file/:name/base64", (req, res) => {
  const fp = path.join(FILES_DIR, req.params.name);
  if (!fs.existsSync(fp)) return res.status(404).json({ error: "Not found" });
  res.json({ base64: fs.readFileSync(fp).toString("base64") });
});

app.delete("/api/file/:name", (req, res) => {
  const fp = path.join(FILES_DIR, req.params.name);
  if (fs.existsSync(fp)) fs.unlinkSync(fp);
  res.json({ ok: true });
});

app.get("/api/open-folder", (req, res) => {
  const cmd = process.platform === "win32" ? `explorer "${FILES_DIR}"` : `open "${FILES_DIR}"`;
  exec(cmd);
  res.json({ ok: true, path: FILES_DIR });
});

app.listen(PORT, () => {
  console.log(`\n✅ Hassan Tax World — Server running on port ${PORT}`);
  console.log(`   Files folder : ${FILES_DIR}`);
  if (!ANTHROPIC_API_KEY || ANTHROPIC_API_KEY === "YOUR_API_KEY_HERE") {
    console.log(`\n⚠️  AI NOT CONFIGURED — open server.cjs and add your Anthropic API key\n`);
  } else {
    console.log(`   AI           : ✓ Anthropic API key set\n`);
  }
});
